package org.owasp.csrfguard.token;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.servlet.ServletException;

import org.owasp.csrfguard.CSRFException;
import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.crypto.UniqueIdGenerator;


public class OwaspTokenStrategy implements TokenStrategy {

	private static final String CSRFGUARD_PROPERTIES = "CSRFGuard.properties";  //TODO this should be configurable
	private static final int RANDOM_NAME_LENGTH = 10;
	private GuardContext context;

	public OwaspTokenStrategy() {
		InputStream stream = this.getClass().getResourceAsStream(CSRFGUARD_PROPERTIES);
		Properties props = new Properties();
		try {
			props.load(stream);
			context = new GuardContext(props);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ServletException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String newTokenValue() {
		try {
			return UniqueIdGenerator.generateRandomId(context.getPRNG(), context.getTokenLength());
		} catch (Exception e) {
			throw new CSRFException("Error generating token value", e);
		}
	}

	public String newTokenName() {
		try{
			String name = context.getTokenName();
			if (name==null||name.length()==0){
				name = UniqueIdGenerator.generateRandomId(context.getPRNG(), RANDOM_NAME_LENGTH);
			}
			return name;
		} catch(Exception e){
			throw new CSRFException("Error generating token name", e);
		}
	}

}
