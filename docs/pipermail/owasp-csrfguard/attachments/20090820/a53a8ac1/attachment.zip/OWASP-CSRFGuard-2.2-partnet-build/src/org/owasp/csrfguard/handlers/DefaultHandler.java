package org.owasp.csrfguard.handlers;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public class DefaultHandler extends ResponseHandler {

	@Override
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context, String token, String tokenName) {
		// TODO Auto-generated method stub

	}

}
