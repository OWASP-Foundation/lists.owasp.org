/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard;

/**
 * CSRFException is an exception that denotes the occurrence of a CSRF attack.
 */
public final class CSRFException extends SecurityException {
	
	private final static long serialVersionUID = 0xaed48214;
	
	/**
	 * Construct a CSRFException with the specified error message.
	 * @param msg
	 */
	public CSRFException(String msg) {
		super("[OWASP CSRFGuard] " + msg);
	}
	
	/**
	 * Construct a CSRFException with a specified error message and root cause.
	 * @param msg
	 * @param e
	 */
	public CSRFException(String msg, Exception e) {
		super("[OWASP CSRFGuard] " + msg, e);
	}
	
	/**
	 * Construct a CSRFException with the specified error message and tokens.
	 * @param msg
	 * @param oToken
	 * @param nToken
	 */
	public CSRFException(String msg, String oToken, String nToken) {
		super("[OWASP CSRFGuard] " + msg + " - (session:" + oToken + ", request:" + nToken + ")");
	}
}
