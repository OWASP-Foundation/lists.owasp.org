package org.owasp.csrfguard.tags;

import java.io.*;
import javax.servlet.jsp.tagext.TagSupport;
import javax.servlet.http.HttpSession;

import org.owasp.csrfguard.GuardContext;

public final class TokenValue extends TagSupport {

	private final static long serialVersionUID = 0xadede854;

	public int doStartTag() {
		final HttpSession session = pageContext.getSession();
		final String tokenValue = (String)session.getAttribute(GuardContext.TOKEN_VALUE_KEY);
		
		try {
			pageContext.getOut().write(tokenValue);
		} catch (IOException e) {
			pageContext.getServletContext().log(e.getLocalizedMessage(), e);
		}
		
		return SKIP_BODY;
	}
}
