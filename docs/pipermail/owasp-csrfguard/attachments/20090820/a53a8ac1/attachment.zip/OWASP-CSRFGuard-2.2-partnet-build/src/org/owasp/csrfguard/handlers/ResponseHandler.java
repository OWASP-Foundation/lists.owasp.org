/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.handlers;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public abstract class ResponseHandler {
	
	private String name = null;
	
	private Map<String, String> parameters = new HashMap<String, String>();
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setHandlerParameter(String name, String value) {
		parameters.put(name, value);
	}
	
	public String getHandlerParameter(String name) {
		return parameters.get(name);
	}
	
	public int getHandlerParameterCount() {
		return parameters.size();
	}
	
	/**
	 * Invoked when the HTML of the response must be modified to contain the HTML token.
	 * @param request
	 * @param response
	 * @param context
	 * @param token
	 */
	public abstract void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context, String token, String tokenName);
	
}
