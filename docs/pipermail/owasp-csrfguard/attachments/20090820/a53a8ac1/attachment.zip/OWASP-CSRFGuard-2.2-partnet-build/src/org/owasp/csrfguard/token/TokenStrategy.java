/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://part.net">PartNet</a>
 * @created 2009
 */
package org.owasp.csrfguard.token;


/**
 * This interface should abstract the strategies used to generate token names and token values.
 */
public interface TokenStrategy
{

  /**
   * @return a new TokenValue as a string or null indicating another strategy should be used.
   * @throws CSRFFrameworkException when an unexpected error occurs
   */
  String newTokenValue();

  /**
   * @return a new TokenName as a string or null indicating another strategy should be used.
   * @throws CSRFFrameworkException when an unexpected error occurs
   */
  String newTokenName();

}
