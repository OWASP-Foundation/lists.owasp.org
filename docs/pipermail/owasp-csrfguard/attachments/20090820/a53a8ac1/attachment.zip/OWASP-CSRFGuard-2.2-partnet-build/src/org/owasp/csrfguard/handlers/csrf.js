<script language="JavaScript">

var tokenName = '<%NAME%>';
var tokenValue = '<%VALUE%>';

function updateTags() {

	var all = document.all ? document.all : document.getElementsByTagName('*');
	var len = all.length;

	for(var i=0; i<len; i++) {
		var e = all[i];
		
		updateTag(e, 'src');
		updateTag(e, 'href');
	}
}

function updateForms() {

	var forms = document.getElementsByTagName('form');
		
	for(i=0; i<forms.length; i++) {
		var html = forms[i].innerHTML;
		
		html += '<input type=hidden name=' + tokenName + ' value=' + tokenValue + ' />';

		forms[i].innerHTML = html;
	}

}

function updateTag(element, attr) {

	var location = element.getAttribute(attr);

	if(location != null && location != '' && isHttpLink(location)) {

		var index = location.indexOf('?');

		if(index != -1) {
			location = location + '&' + tokenName + '=' + tokenValue;
		} else {
			location = location + '?' + tokenName + '=' + tokenValue;
		}

		element.setAttribute(attr, location);

	}

}

function isHttpLink(src) {
	var result = 0;
		
	if(src.substring(0, 4) == 'http' || src.substring(0, 1) == '/') {
		result = 1;
	}
	
	return result;
}

updateTags();
updateForms();

</script>