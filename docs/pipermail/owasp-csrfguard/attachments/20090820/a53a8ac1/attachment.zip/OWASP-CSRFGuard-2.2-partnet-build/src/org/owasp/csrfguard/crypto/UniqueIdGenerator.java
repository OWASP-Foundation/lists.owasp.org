/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.crypto;

import java.io.UnsupportedEncodingException;
import java.security.SecureRandom;
import java.security.NoSuchAlgorithmException;

/**
 * A utility class that generates random identifiers.
 */
public final class UniqueIdGenerator {
	
	private final static char[] CHARSET = new char[] {
		'A','B','C','D','E','F','G','H','I','J','K','L','M',
		'N','O','P','Q','R','S','T','U','V','W','X','Y','Z',
		'0','1','2','3','4','5','6','7','8','9'
	};
	
	private UniqueIdGenerator() {
		/**
		 * Intentionally blank to force static usage
		 */
	}
	
	/**
	 * Generate a random identifier given a specified PRNG and length.
	 * @param prng
	 * @param len
	 * @return
	 * @throws NoSuchAlgorithmException
	 * @throws UnsupportedEncodingException
	 */
	public static String generateRandomId(String prng, int len) throws NoSuchAlgorithmException, UnsupportedEncodingException {
		SecureRandom sr = SecureRandom.getInstance(prng);
		StringBuffer sb = new StringBuffer();
		
		for(int i=1; i<len+1; i++) {
			int index = sr.nextInt(CHARSET.length);
			char c = CHARSET[index];
			sb.append(c);
			
			if((i%4) == 0 && i != 0 && i<len) {
				sb.append('-');
			}
		}
		
		return sb.toString();
	}
	
}
