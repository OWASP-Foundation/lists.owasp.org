/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://part.net">PartNet</a>
 * @created 2009
 */
package org.owasp.csrfguard.token;

import java.util.Map;

import javax.security.auth.Subject;
import javax.security.auth.callback.CallbackHandler;
import javax.security.auth.login.LoginException;
import javax.security.auth.spi.LoginModule;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * The TokenLoginModule will places a TokenCredential on the subject as a PublicCredential.
 * This module doesn't do any authentication and ignores the passed in callbacks, as such should
 * only be marked as REQUIRED or OPTIONAL, but never REQUISITE or SUFFICIENT.
 * "TokenStrategy" can be passed in as a configuration parameter to alter the default token
 * generation strategy.
 */
public class TokenLoginModule
  implements LoginModule
{
  static final String TOKEN_STRATEGY = "TokenStrategy";
  static final private TokenStrategy defaultStrategy = new VariableLengthTokenStrategy(); 
  private TokenStrategy tokenStrategy = defaultStrategy;
  private static final Logger log = Logger.getLogger(TokenLoginModule.class.getName());

  private Subject subject;

  private TokenCredential tokenCredential;

  public boolean abort()
    throws LoginException
  {
    tokenCredential = null;
    return true;
  }

  public boolean commit()
    throws LoginException
  {
    if (tokenCredential == null) {
      return false;
    }
    else {
      subject.getPublicCredentials().add(tokenCredential);
      return true;
    }
  }

  /** 
   * initialize can optionally handle a "TokenStrategy" parameter of a class name that implements TokenStrategy
   */
  public void initialize(Subject subject, CallbackHandler callbackHandler, Map<String, ?> sharedState, Map<String, ?> options)
  {
    this.subject = subject;
      
    String tokenStrategyClassName = (String)options.get(TOKEN_STRATEGY);
    if (tokenStrategyClassName != null){
      try {
        Class<?> strategy = Class.forName(tokenStrategyClassName);
        
        if (strategy != null ){ 
          this.tokenStrategy = (TokenStrategy)strategy.newInstance();
        } else {
          throw new Exception(
               "TokenLoginModule could not load class for the configured TokenStrategy: "
               +tokenStrategyClassName);
        }
      }
      catch (Exception e) {
        log.log(Level.SEVERE, "TokenLoginModule could not load the configured token strategy:"+tokenStrategyClassName, e);
      }
    } else {
      this.tokenStrategy = defaultStrategy;
    }
  }

  public boolean login()
    throws LoginException
  {
    tokenCredential = new TokenCredential(tokenStrategy.newTokenName(), tokenStrategy.newTokenValue());
    return true;
  }

  public boolean logout()
    throws LoginException
  {
    subject.getPublicCredentials().remove(tokenCredential);
    tokenCredential = null;
    subject = null;
    return true;
  }

}
