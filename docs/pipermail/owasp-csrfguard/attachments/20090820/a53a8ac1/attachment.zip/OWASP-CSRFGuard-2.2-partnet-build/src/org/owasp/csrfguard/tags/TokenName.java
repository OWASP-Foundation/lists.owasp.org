package org.owasp.csrfguard.tags;

import java.io.*;
import javax.servlet.jsp.tagext.*;
import javax.servlet.http.HttpSession;

import org.owasp.csrfguard.GuardContext;

public final class TokenName extends TagSupport {

	private final static long serialVersionUID = 0xadede854;

	public int doStartTag() {
		HttpSession session = pageContext.getSession();
		String tokenName = (String)session.getAttribute(GuardContext.TOKEN_NAME_KEY);
		
		try {
			pageContext.getOut().write(tokenName);
		} catch (IOException e) {
			pageContext.getServletContext().log(e.getLocalizedMessage(), e);
		}
		
		return SKIP_BODY;
	}
}