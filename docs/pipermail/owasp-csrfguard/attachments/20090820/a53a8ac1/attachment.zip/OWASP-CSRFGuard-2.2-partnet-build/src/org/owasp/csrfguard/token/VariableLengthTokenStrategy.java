/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://part.net">PartNet</a>
 * @created 2009
 */
package org.owasp.csrfguard.token;

import java.security.SecureRandom;


/**
 * This Token generation strategy generates tokens with alpha-numberic characters.  Names and values
 * are random using the default JVM sha1 psuedo random number generator(this can be configured by the JVM
 * security policy).  Both parameter names and values have variable lengths to prevent automated detection of tokens.
 */
public class VariableLengthTokenStrategy
  implements TokenStrategy
{
  // Having names and values with a predictable length may help bypass 
  // CSRFGuard protections when CSS vulnerabilities exists
  static final int DEFAULT_TOKEN_LENGTH_MIN = 22;

  static final int DEFAULT_TOKEN_LENGTH_MAX = 36;

  static final int DEFAULT_NAME_LENGTH_MIN = 7;

  static final int DEFAULT_NAME_LENGTH_MAX = 14;

  private final SecureRandom srand;

  private final char[] tokenChars = {'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p',
      'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L',
      'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '1', '2', '3', '4', '5', '6', '7', '8', '9'};

  public VariableLengthTokenStrategy()
  {
	//Note that the PSNG default algorithm is configurable in the JVM security settings 
    srand = new SecureRandom();
  }

  public String newTokenName()
  {
    int nameLength = srand.nextInt(DEFAULT_NAME_LENGTH_MAX - DEFAULT_NAME_LENGTH_MIN) + DEFAULT_NAME_LENGTH_MIN;
    String name = getRandomValue(nameLength);
    return name;
  }

  /**
   * @param nameLength length of the returned random string
   * @return a string with random alpha-numeric characters of specified length
   */
  String getRandomValue(int nameLength)
  {
    StringBuilder sb = new StringBuilder();
    while (sb.length() < nameLength) {
      int index = srand.nextInt(tokenChars.length);
      sb.append(tokenChars[index]);
    }
    return sb.toString();
  }

  public String newTokenValue()
  {
    int tokenLength = srand.nextInt(DEFAULT_TOKEN_LENGTH_MAX - DEFAULT_TOKEN_LENGTH_MIN) + DEFAULT_TOKEN_LENGTH_MIN;
    String token = getRandomValue(tokenLength);
    return token;
  }

}
