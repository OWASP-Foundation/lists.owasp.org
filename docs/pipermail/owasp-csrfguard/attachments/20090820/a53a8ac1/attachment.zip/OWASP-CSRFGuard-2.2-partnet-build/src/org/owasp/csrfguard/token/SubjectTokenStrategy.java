/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://part.net">PartNet</a>
 * @created 2009
 */
package org.owasp.csrfguard.token;

import java.security.AccessController;
import java.util.Iterator;
import java.util.Set;

import javax.security.auth.Subject;

/**
 * SubjectTokenStrategy will get token values and names from a public credential 
 * placed on a Subject at login time.  Specifically, the TokenLoginModule will 
 * place a TokenCredential on the subject as a PublicCredential.
 */
public class SubjectTokenStrategy
  implements TokenStrategy
{

  /**
   * @returns the token name stored on a subject from the current thread
   */
  public String newTokenName()
  {
    TokenCredential token = getToken();

    if (token == null)
      return null;
    else
      return token.getTokenName();
  }

  /**
   * @returns the token value stored on a subject from the current thread
   */
  public String newTokenValue()
  {
    TokenCredential token = getToken();

    if (token == null)
      return null;
    else
      return token.getTokenValue();
  }

  /**
   * @return TokenCredential that is stored on the current thread's subject's public credentials.
   */
  private TokenCredential getToken()
  {
    TokenCredential token = null;
    Subject subject = Subject.getSubject(AccessController.getContext());
    
    if (subject != null) {
      Set<TokenCredential> tokenPrincipalSet = subject.getPublicCredentials(TokenCredential.class);
      Iterator<TokenCredential> tokens = tokenPrincipalSet.iterator();
  
      if (tokens.hasNext()) {
        token = tokens.next();
      }
    }
    return token;
  }
}
