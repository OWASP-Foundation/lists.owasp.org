/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard;

import java.io.InputStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.LinkedList;
import java.util.Map;
import java.util.HashMap;
import java.util.Properties;
import java.util.regex.Pattern;
import java.util.regex.PatternSyntaxException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.http.MutableHttpResponse;
import org.owasp.csrfguard.handlers.ResponseHandler;
import org.owasp.csrfguard.token.TokenStrategy;
import org.owasp.csrfguard.token.VariableLengthTokenStrategy;
import org.owasp.csrfguard.actions.AbstractAction;
import org.owasp.csrfguard.actions.ActionException;

/**
 * GuardContext maintains all of the properties associated with the deployed CSRFGuard instance.
 */
public final class GuardContext {
	
	public final static String TOKEN_NAME_KEY = "__CSRFGUARD_TOKEN_NAME";
	public final static String TOKEN_VALUE_KEY = "__CSRFGUARD_TOKEN_VALUE";
	
	private ServletContext servletContext = null;
	
	private ResponseHandler responseHandler = null;
	
	private String tokenName = null;
	
	private int tokenLength = -1;
	
	private String prng = null;
	
	private String newTokenRedirectPage = null;
	
	private Pattern[] entryPoints = null;
	
	private Pattern[] unprotectedPages = null;
	
	private boolean parameterlessValidation = false;
	
	private AbstractAction[] actions = null;
	private TokenStrategy tokenStrategy;
	
	/**
	 * Construct the GuardContext with the specified ServletContext and CSRFGuard properties file.
	 * @param servletContext
	 * @param configFileName
	 * @throws ServletException
	 */
	public GuardContext(ServletContext servletContext, String configFileName) throws ServletException {
		this.servletContext = servletContext;
		
		Properties p = getPropertiesFromFile(configFileName);
		setProperties(p);
	}

	private void setProperties(Properties p) throws ServletException {
		setResponseHandler(p, "org.owasp.csrfguard.handler");
		setTokenName(getProperty(p, "org.owasp.csrfguard.TokenName", false));
		setTokenLength(getPropertyAsInt(p, "org.owasp.csrfguard.TokenLength", true));
		setPRNG(getProperty(p, "org.owasp.csrfguard.PRNG", true));
		setEntryPoints(p, "org.owasp.csrfguard.entrypoint");
		setUnprotectedPages(p, "org.owasp.csrfguard.unprotected");
		setParameterlessValidation(getPropertyAsBoolean(p, "org.owasp.csrfguard.ParameterlessValidation", false));
		setActions(p, "org.owasp.csrfguard.action.class");
		setNewTokenRedirectPage(getProperty(p, "org.owasp.csrfguard.NewTokenRedirectPage", false));
		setTokenStrategy(getProperty(p, "org.owasp.csrfguard.TokenStrategy", false));
	}

	public GuardContext(Properties props) throws ServletException{
		setProperties(props);
	}
	
	/**
	 * Set the new token redirect page.
	 * @param newTokenRedirectPage
	 */
	private void setNewTokenRedirectPage(String newTokenRedirectPage) {
		this.newTokenRedirectPage = newTokenRedirectPage;
	}
	
	/**
	 * Set the response handler defined in the properties file.
	 * @param p
	 * @param classKey
	 * @throws ServletException
	 */
	private void setResponseHandler(Properties p, String classKey) throws ServletException {
		final String prefix = classKey + ".";
		final int prefixLength = prefix.length();
		Enumeration<?> e = p.propertyNames();
		Map<String, String> parameters = new HashMap<String, String>();
		
		while(e.hasMoreElements()) {
			String s = (String)e.nextElement();
			
			if(s.startsWith(prefix)) {
				char[] array = s.toCharArray();
				boolean isClass = true;
				int len = array.length;
				
				for(int i=prefixLength; i<len; i++) {
					if(array[i] == '.') {
						isClass = false;
						break;
					}
				}
				
				/** its either a class or a parameter **/
				if(isClass) {
					newResponseHandler((String)p.getProperty(s));
				} else {
					int index = s.lastIndexOf('.') + 1;
					String name = s.substring(index, s.length());
					String value = (String)p.getProperty(s);
					
					parameters.put(name, value);
				}
			}
		}
		
		e = Collections.enumeration(parameters.keySet());
		
		while(e.hasMoreElements()) {
			String name = (String)e.nextElement();
			String value = parameters.get(name);
			
			responseHandler.setHandlerParameter(name, value);
		}
	}
	
	/**
	 * Set the actions defined in the properties file.
	 * @param p
	 * @param classKey
	 * @throws ServletException
	 */
	private void setActions(Properties p, String classKey) throws ServletException {
		actions = getActions(p, classKey);
	}
	
	/**
	 * Instantiate and retrieve the actions defined in the properties file.
	 * @param p
	 * @param classKey
	 * @return
	 * @throws ServletException
	 */
	private AbstractAction[] getActions(Properties p, String classKey) throws ServletException {
		AbstractAction[] actions = getActionsFromProperties(p, classKey);
		
		loadActionParameters(actions, p, classKey);
		
		return actions;
	}
	
	private void loadActionParameters(AbstractAction[] actions, Properties p, String classKey) {
		
		for(int i=0; i<actions.length; i++) {
			AbstractAction action = actions[i];
			String name = action.getName();
			final String key = classKey + "." + action.getName() + ".";
			
			String[] initParamNames = getInitParamNames(p, name, key);
			
			loadActionParameters(p, action, initParamNames, key);
		}
	}
	
	private void loadActionParameters(Properties p, AbstractAction action, String[] paramNames, String key) {
		
		for(int i=0; i<paramNames.length; i++) {
			String fullName = paramNames[i];
			String value = p.getProperty(fullName);
			String paramName = fullName.substring(key.length(), fullName.length());
			
			action.setActionParameter(paramName, value);
		}
	}
	
	private String[] getInitParamNames(Properties p, String name, final String key)
	{
		List<String> names = new LinkedList<String>();
		Enumeration<Object> e = p.keys();
		
		while(e.hasMoreElements()) {
			String s = (String)e.nextElement();
			
			if(s.startsWith(key)) {
				names.add(s);
			}
		}
		
		return (names.toArray(new String[names.size()]));
	}
	
	private AbstractAction[] getActionsFromProperties(Properties p, String classKey) throws ServletException
	{
		final String prefix = classKey + ".";
		final int prefixLength = prefix.length();
		Enumeration<Object> e = p.keys();
		List<AbstractAction> actions = new LinkedList<AbstractAction>();
		
		while(e.hasMoreElements()) {
			String s = (String)e.nextElement();
			
			if(s.startsWith(prefix)) {
				char[] array = s.toCharArray();
				boolean isClass = true;
				int len = array.length;
				
				for(int i=prefixLength; i<len; i++) {
					if(array[i] == '.') {
						isClass = false;
						break;
					}
				}
				
				if(isClass) {
					AbstractAction action = newAction(p.getProperty(s));
					
					action.setName(s.substring(prefixLength, len));
					actions.add(action);
				}
			}
		}
		
		return (actions.toArray(new AbstractAction[actions.size()]));
	}
	
	private AbstractAction newAction(String className) throws ServletException {
		AbstractAction action = null;
		
		try {
			Class<?> c = Class.forName(className);
			Object o = c.newInstance();
			
			action = (AbstractAction)o;
		} catch (Exception e) {
			throw new ServletException("unable to load the action " + className + ": " + e.getLocalizedMessage(), e);
		}
		
		return action;
	}
	
	private void setParameterlessValidation(boolean parameterlessValidation) {
		this.parameterlessValidation = parameterlessValidation;
	}
	
	private void setEntryPoints(Properties p, String key) throws ServletException {
		entryPoints = getPatternPages(p, key);
	}
	
	private void setUnprotectedPages(Properties p, String key) throws ServletException {
		unprotectedPages = getPatternPages(p, key);
	}
	
	private Pattern[] getPatternPages(Properties p, String key) throws ServletException {
		List<Pattern> patterns = new LinkedList<Pattern>();
		Enumeration<?> e = p.propertyNames();
		
		while(e.hasMoreElements()) {
			String s = (String)e.nextElement();
			
			if(s.startsWith(key)) {
				String value = p.getProperty(s);
				try {
					Pattern pattern = Pattern.compile(value);
					
					patterns.add(pattern);
				} catch (PatternSyntaxException pse) {
					throw new ServletException("unable to compile the following pattern: " + pse.getLocalizedMessage(), pse);
				}
			}
		}
		
		return patterns.toArray(new Pattern[patterns.size()]);
	}
	
	/**
	 * @deprecated Please use JVM security settings to configure default PRNG
	 */
	private void setPRNG(String prng) {
		this.prng = prng;
	}
	
	private void setTokenLength(int tokenLength) {
		this.tokenLength = tokenLength;
	}
	
	/**
	 * @deprecated see getTokenStrategy
	 */
	private void setTokenName(String tokenName) {
		this.tokenName = tokenName;
	}
	
	private void newResponseHandler(String className) throws ServletException {
		try {
			Class<?> c = Class.forName(className);
			Object o = c.newInstance();
			
			responseHandler = (ResponseHandler)o;
		} catch (Exception e) {
			throw new ServletException("unable to instantiate the response handler " + className + ": " + e.getLocalizedMessage(), e);
		}
	}
	
	private boolean getPropertyAsBoolean(Properties p, String key, boolean required) throws ServletException {
		String s = getProperty(p, key, required);
		
		return Boolean.parseBoolean(s);
	}
	
	private int getPropertyAsInt(Properties p, String key, boolean required) throws ServletException {
		String s = getProperty(p, key, required);
		int n = -1;
		
		try {
			n = Integer.parseInt(s);
		} catch (NumberFormatException nfe) {
			throw new ServletException("the property " + key + " is not a valid int: " + s, nfe);
		}
		
		return n;
	}
	
	private String getProperty(Properties p, String key, boolean required) throws ServletException {
		String s = p.getProperty(key);
		
		if(s == null && required) throw new ServletException("unable to retrieve the value of the following property: " + key);
		
		return s;
	}
	
	private Properties getPropertiesFromFile(String fileName) throws ServletException {
		InputStream is = getConfigStream(fileName);
		Properties p = new Properties();
		
		try {
			p.load(is);
		} catch (IOException ioe) {
			throw new ServletException("unable to parse the CSRFGuard properties file: " + ioe.getLocalizedMessage());
		} finally {
			if(is != null) {
				try {
					is.close();
				} catch (IOException ioe) {
					// ignore
				}
			}
		}
		
		return p;
	}
	
	private InputStream getConfigStream(String fileName) throws ServletException {
		InputStream is = null;
		
		try {
			is = new FileInputStream(fileName);
		} catch (IOException ioe) {
			throw new ServletException("unable to obtain CSRFGuard input stream: " + fileName);
		}
		
		return is;
	}
	
	public boolean isEntryPoint(String uri) {
		boolean result = false;
		int len = (entryPoints == null ? -1 : entryPoints.length);
		
		for(int i=0; i<len; i++) {
			Pattern p = entryPoints[i];
			
			if(p.matcher(uri).matches()) {
				result = true;
				break;
			}
		}
		
		return result;
	}
	
	public boolean isProtectedPage(String uri) {
		boolean result = true;
		int len = (unprotectedPages == null ? -1 : unprotectedPages.length);
		
		for(int i=0; i<len; i++) {
			Pattern p = unprotectedPages[i];
			
			if(p.matcher(uri).matches()) {
				result = false;
				break;
			}
		}
		
		return result;
	}

	public ServletContext getServletContext() {
		return servletContext;
	}

	public ResponseHandler getResponseHandler() {
		return responseHandler;
	}

	/**
	 * @deprecated see getTokenStrategy
	 */
	public String getTokenName() {
		return tokenName;
	}

	public int getTokenLength() {
		return tokenLength;
	}

	/**
	 * @deprecated Please use JVM security settings to configure default PRNG
	 */
	public String getPRNG() {
		return prng;
	}

	public boolean isParameterlessValidation() {
		return parameterlessValidation;
	}
	
	public void log(Throwable t) {
		servletContext.log(t.getLocalizedMessage(), t);
	}
	
	public void log(String msg, Throwable t) {
		servletContext.log(msg, t);
	}
	
	public void log(String msg) {
		servletContext.log(msg);
	}

	public String getNewTokenRedirectPage() {
		return newTokenRedirectPage;
	}
	
	public void doActions(HttpServletRequest request, MutableHttpResponse response) {
		int len = (actions == null ? -1 : actions.length);
		
		for(int i=0; i<len; i++) {
			AbstractAction action = actions[i];
			
			try {
				action.service(request, response, this);
			} catch (ActionException ae) {
				log(ae);
			}
		}
	}

	private void setTokenStrategy(String tokenStrategyClassName) {
		if (tokenStrategyClassName == null || tokenStrategyClassName.length()==0){
			tokenStrategy = new VariableLengthTokenStrategy();
		} else {
			try {
	        Class<?> strategy = Class.forName(tokenStrategyClassName);
	        
	        if (strategy != null ){ 
	          this.tokenStrategy = (TokenStrategy)strategy.newInstance();
	        } else {
	          throw new Exception(
	               "TokenLoginModule could not load class for the configured TokenStrategy: "
	               +tokenStrategyClassName);
            }
	      }
	      catch (Exception e) {
	        log("TokenLoginModule could not load the configured token strategy:"+tokenStrategyClassName, e);
	        tokenStrategy = new VariableLengthTokenStrategy();
	      }
		}
	}
	
	public TokenStrategy getTokenStrategy() {
		return tokenStrategy;
	}
}
