/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.handlers;

import java.io.IOException;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

/**
 * 
 * @author esheridan
 * @deprecated
 */
public final class RegExHandler extends ResponseHandler {

	private final static String FORM_PATTERN = "FormPattern";
	
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context, String token, String tokenName) {
		try {
			doToken(response, tokenName, token);
		} catch (Exception e) {
			context.log(e.getLocalizedMessage(), e);
		}
	}

	private void doToken(MutableHttpResponse response, String tokenName, String token) throws IOException {
		String content = new String(response.getContent());

		content = buildLinkParameters(content, tokenName, token);

		response.setContent(content);
	}

	private String buildLinkParameters(String content, String tokenName, String token) {
		
		content = buildFormParameters(content, tokenName, token);
		content = buildLinkParameters(content, tokenName, token, "href=\"", '"');
		content = buildLinkParameters(content, tokenName, token, "src=\"", '"');

		return content;
	}

	private String buildFormParameters(String content, String tokenName, String token) {
		String s = getHandlerParameter(FORM_PATTERN);
		Pattern formPattern = Pattern.compile(s);
		return formPattern.matcher(content).replaceAll("<input type=\"hidden\" name=\"" + tokenName + "\" value=\"" + token + "\">\n</form>");
	}

	/**
	 * FIXME: - TOO COMPLEX! - BUG: we will be adding tokens to JavaScript hrefs -
	 * javascript:toggle('some') => javascript:toggle('some')?OWASP_CS...
	 * 
	 * @param content
	 * @param token
	 * @param pattern
	 * @param termChar
	 * @return
	 */
	private String buildLinkParameters(String content, String tokenName, String token, String pattern, char termChar) {
		StringBuffer buffer = new StringBuffer();
		int i = 0;
		int index = 0;
		int length = content.length();

		while (i < length) {
			String s = content.toLowerCase();
			index = s.indexOf(pattern, i);

			if (index != -1) {
				int offset = 0;
				int n = 0;
				boolean parameters = false;
				String tokenString = null;
				buffer.append(content.substring(i, index + pattern.length()));

				for (n = index + pattern.length(), offset = n; n <= length && content.charAt(n) != termChar; n++) {
					buffer.append(content.charAt(n));

					if (content.charAt(n) == '?') {
						parameters = true;
					}
				}

				if (parameters) {
					tokenString = "&" + tokenName + "=" + token;
				} else {
					tokenString = "?" + tokenName + "=" + token;
				}

				buffer.append(tokenString);

				i = index + pattern.length() + (n - offset);
			} else {
				buffer.append(content.substring(i, length));

				i = length;
			}
		}

		return buffer.toString();
	}
}
