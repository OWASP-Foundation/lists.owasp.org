/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.handlers;

import javax.servlet.http.HttpServletRequest;

import org.htmlparser.Node;
import org.htmlparser.Parser;
import org.htmlparser.nodes.TagNode;
import org.htmlparser.tags.FormTag;
import org.htmlparser.tags.InputTag;
import org.htmlparser.tags.LinkTag;
import org.htmlparser.tags.ScriptTag;
import org.htmlparser.util.NodeIterator;
import org.htmlparser.util.NodeList;
import org.htmlparser.util.ParserException;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public final class HTMLParserHandler extends ResponseHandler {
	
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context, String token, String tokenName) {
		try {
			Parser p = new Parser();
			
			p.setResource(new String(response.getContent()));
			
			NodeList nl = p.parse(null);
			NodeIterator itr = nl.elements();

			while (itr.hasMoreNodes()) {
				Node n = (Node) itr.nextNode();
				processNodes(n, tokenName, token);
			}

			response.setContent(nl.toHtml());
		} catch (Exception e) {
			context.log("error parsing the response of the requested resource - Transmitting the response content without the unique random token.", e);
		}
	}

	private void processNodes(Node node, String tokenName, String token) throws ParserException {
		if (node instanceof LinkTag) {
			LinkTag link = (LinkTag) node;
			
			if (link.isHTTPLink() || link.isHTTPSLink()) {
				updateTag(link, "href", tokenName, token);
			}
		} else if (node instanceof FormTag) {
			FormTag ft = (FormTag) node;
			InputTag it = new InputTag();

			it.setAttribute("type", "hidden");
			it.setAttribute("name", tokenName);
			it.setAttribute("value", token);

			NodeList children = ft.getChildren();

			children.add(it);

			ft.setChildren(children);
		} else if (node instanceof TagNode) {
			TagNode tag = (TagNode) node;

			updateTag(tag, "href", tokenName, token);
			updateTag(tag, "src", tokenName, token);

			NodeList nl = tag.getChildren();

			if (nl != null) {
				for (NodeIterator itr = nl.elements(); itr.hasMoreNodes(); processNodes(itr.nextNode(), tokenName, token));
			}
		} else if(node instanceof ScriptTag) {
			/**
			 * TODO: Place the token in the JavaScript.
			 */
		}
	}

	private void updateTag(TagNode tag, String attr, String tokenName, String token) {
		String text = tag.getAttribute(attr);

		if (text != null && text.length() > 0) {
			if (text.indexOf("?") != -1) {
				text = text.replace("?", "?" + tokenName + "=" + token + "&");
			} else {
				text = text + "?" + tokenName + "=" + token;
			}

			tag.setAttribute(attr, text);
		}
	}
}
