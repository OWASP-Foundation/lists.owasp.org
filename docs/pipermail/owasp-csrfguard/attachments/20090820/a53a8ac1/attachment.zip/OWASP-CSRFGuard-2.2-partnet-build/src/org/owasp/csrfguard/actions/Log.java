package org.owasp.csrfguard.actions;

import java.io.UnsupportedEncodingException;
import java.util.Enumeration;

import java.net.URLEncoder;
import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public final class Log extends AbstractAction {

	@Override
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws ActionException {
		String logMessage = getLogMesssage(request);
		
		context.log(logMessage);
	}
	
	private String getLogMesssage(HttpServletRequest request) throws ActionException {
		String logMessage = getActionParameter("Message");
		
		/** Remote Network Information **/
		logMessage = logMessage.replaceAll("%remote_ip", request.getRemoteAddr());
		logMessage = logMessage.replaceAll("%remote_host", request.getRemoteHost());
		logMessage = logMessage.replaceAll("%remote_port", String.valueOf(request.getRemotePort()));
		
		/** Local Network Information **/
		logMessage = logMessage.replaceAll("%local_ip", request.getLocalAddr());
		logMessage = logMessage.replaceAll("%local_host", request.getLocalName());
		logMessage = logMessage.replaceAll("%local_port", String.valueOf(request.getLocalPort()));
		
		/** Requested Resource Information **/
		logMessage = logMessage.replaceAll("%request_uri", request.getRequestURI());
		logMessage = logMessage.replaceAll("%request_url", request.getRequestURL().toString());
		
		/** Parameters **/
		logMessage = logMessage.replaceAll("%request_query_string", encode(request.getQueryString()));;
		logMessage = logMessage.replaceAll("%request_parameters", getEncodedRequestParameters(request));
		
		return logMessage;
	}
	
	private String getEncodedRequestParameters(HttpServletRequest request) throws ActionException {
		StringBuffer sb = new StringBuffer();
		Enumeration<?> e = request.getParameterNames();
		
		sb.append("(");
		
		while(e.hasMoreElements()) {
			String name = (String)e.nextElement();
			String[] values = request.getParameterValues(name);
			
			if(values != null) {
				int len = values.length;
				
				for(int i=0; i<len; i++) {
					sb.append(encode(name));
					sb.append('=');
					sb.append(encode(values[i]));
					
					if((i+1) < len) {
						sb.append(',');
					} else if(e.hasMoreElements()){
						sb.append(':');
					}
				}
				
			} else {
				sb.append(encode(name));
				sb.append('=');
				sb.append("null");
			}
		}
		
		sb.append(")");
		
		return sb.toString();
	}
	
	private String encode(String s) throws ActionException {
		String result = null;
		
		try {
			result = (s == null ? null : URLEncoder.encode(s, "UTF-8"));
		} catch (UnsupportedEncodingException uee) {
			throw new ActionException(uee);
		}
		
		return result;
	}
}
