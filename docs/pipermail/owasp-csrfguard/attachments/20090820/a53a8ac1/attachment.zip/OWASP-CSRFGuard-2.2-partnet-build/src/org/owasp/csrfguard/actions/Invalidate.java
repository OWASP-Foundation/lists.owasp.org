package org.owasp.csrfguard.actions;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public final class Invalidate extends AbstractAction {

	@Override
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws ActionException {
		HttpSession session = request.getSession(false);
		
		if(session != null) {
			session.invalidate();
		}
	}

}
