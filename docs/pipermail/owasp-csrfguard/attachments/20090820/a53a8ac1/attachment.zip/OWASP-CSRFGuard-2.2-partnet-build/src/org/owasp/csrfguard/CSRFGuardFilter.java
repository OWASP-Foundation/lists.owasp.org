/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.owasp.csrfguard.http.MutableHttpResponse;

/**
 * The CSRFGuardFilter is a J2EE filter that intercepts and enforces token verification for all requests
 * sent to the target web application.
 */
public class CSRFGuardFilter implements Filter {

	private final static String CONFIG_FILE = "config";
	
	private GuardContext context = null;
	
	/**
	 * @see javax.servlet.Filter#init(FilterConfig)
	 */
	public void init(FilterConfig config) throws ServletException {
		ServletContext servletContext = config.getServletContext();
		
		String s = config.getInitParameter(CONFIG_FILE);
		if(s == null) throw new ServletException("failure to define the 'config' parameter for the CSRFGuardFilter");
		
		String fileName = servletContext.getRealPath(s);
		if(fileName == null) throw new ServletException("unable to locate the real path of the 'config' parameter for CSRFGuardFilter: " + s);
		
		context = new GuardContext(servletContext, fileName);
	}
	
	/**
	 * @see javax.servlet.Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain) throws IOException, ServletException {
		if(req instanceof HttpServletRequest && res instanceof HttpServletResponse) {
			HttpServletRequest request = (HttpServletRequest)req;
			MutableHttpResponse response = new MutableHttpResponse((HttpServletResponse)res);
			
			try {
				doRequestEnforce(request, response);
				
				chain.doFilter(request, response);
				
				doResponseEnforce(request, response);
				
				response.writeContent();
			} catch (CSRFException csrfe) {
				doError(request, response);
			}
		}
	}
	
	/**
	 * @see javax.servlet.Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}
	
	/**
	 * If the request is attempting to access a protected resource, then invoke the CSRFGuard request enforcement logic.
	 * @param request
	 * @param response
	 * @throws IOException
	 * @throws CSRFException
	 */
	private void doRequestEnforce(HttpServletRequest request, MutableHttpResponse response) throws IOException, CSRFException {
		String uri = request.getRequestURI();
		
		if(!context.isEntryPoint(uri) && context.isProtectedPage(uri)) {
			int n = (request.getParameterMap() == null ? -1 : request.getParameterMap().size());
			
			/**
			 * If "isParameterlessValidation" is false, only validate when there is at least one parameter
			 * If "isParameterlessValidation" is true, just validate
			 */
			if(!context.isParameterlessValidation() && n > 0) {
				CSRFGuard guard = new CSRFGuard();
				guard.doRequestEnforce(request, response, context);
			} else if(context.isParameterlessValidation()){
				CSRFGuard guard = new CSRFGuard();
				guard.doRequestEnforce(request, response, context);
			}
		}
	}
	
	/**
	 * Ensure the HTML response has the appropriate token.
	 * @param request
	 * @param response
	 * @throws CSRFException
	 */
	private void doResponseEnforce(HttpServletRequest request, MutableHttpResponse response) throws CSRFException {
		String uri = request.getRequestURI();
		
		if(context.isProtectedPage(uri)) {
			CSRFGuard guard = new CSRFGuard();
			
			guard.doResponseEnforce(request, response, context);
		}
	}
	
	/**
	 * Invoke the CSRFGuard actions when a CSRFException is caught.
	 * @param request
	 * @param response
	 */
	private void doError(HttpServletRequest request, MutableHttpResponse response) {
		context.doActions(request, response);
	}
}
