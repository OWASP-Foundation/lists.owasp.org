/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.handlers;

import java.io.IOException;
import java.io.InputStream;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public final class JavaScriptHandler extends ResponseHandler {
	
	private final static String NAME_STR = "<%NAME%>";

	private final static String VALUE_STR = "<%VALUE%>";

	private final static String JAVASCRIPT_FILE = "/org/owasp/csrfguard/handlers/csrf.js";
	
	private final static String SEARCH_PATTERN = "SearchPattern";
	
	private final static String REPLACE_TEXT = "ReplaceText";
	
	private final static String UPDATE_PLACEHOLDER = "${update}";

	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context, String token, String tokenName) {
		try {
			doToken(response, tokenName, token);
		} catch (Exception e) {
			context.log(e.getLocalizedMessage(), e);
		}
	}

	private void doToken(MutableHttpResponse response, String tokenName, String token) throws IOException {
		String content = new String(response.getContent());

		content = updateHTML(content, tokenName, token);

		response.setContent(content);
	}

	private String updateHTML(String content, String tokenName, String token) throws IOException {
		String update = getFileContent(JAVASCRIPT_FILE);

		update = update.replace(NAME_STR, tokenName);
		update = update.replace(VALUE_STR, token);
		
		String s = getHandlerParameter(SEARCH_PATTERN);
		Pattern searchPattern = Pattern.compile(s);
		
		s = getHandlerParameter(REPLACE_TEXT);
		String replaceText = s.replace(UPDATE_PLACEHOLDER, update);
		
		return searchPattern.matcher(content).replaceAll(replaceText);
	}

	private String getFileContent(String fileName) throws IOException {
		StringBuffer sb = new StringBuffer();
		InputStream is = getResourceStream(fileName);

		try {
			int i = 0;

			while ((i = is.read()) > 0) {
				sb.append((char) i);
			}
		} finally {
			if (is != null) {
				try {
					is.close();
				} catch (IOException ioe) {
					throw new RuntimeException(ioe);
				}
			}
		}

		return sb.toString();
	}
	
	private InputStream getResourceStream(String resourceName) throws IOException {
		InputStream is = getClass().getResourceAsStream(resourceName);
		
		if(is == null) throw new IOException("unable to locate resource: " + resourceName);
		
		return is;
	}
	
}
