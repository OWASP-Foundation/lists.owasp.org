/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://part.net">PartNet</a>
 * @created 2009
 */
package org.owasp.csrfguard.token;


/**
 * Combines multiple token in order.  Starting with the first strategy, newTokenName or newTokenValue
 * is called.  If a null value is return the next strategy is attempts.  Once a non-null value is found
 * that value is returned and no more strategies are attempted.
 */
public class FirstGoodTokenStrategy
  implements TokenStrategy
{

  private TokenStrategy[] strategies;

  public FirstGoodTokenStrategy(TokenStrategy... strategies)
  {
    if (strategies == null) {
      this.strategies = new TokenStrategy[0];
    }
    else {
      this.strategies = strategies;
    }
  }

  public String newTokenName()
  {
    String name = null;
    for (TokenStrategy strategy : strategies) {
      name = strategy.newTokenName();
      if (name != null)
        break;
    }
    return name;
  }

  public String newTokenValue()
  {
    String value = null;
    for (TokenStrategy strategy : strategies) {
      value = strategy.newTokenValue();
      if (value != null)
        break;
    }
    return value;
  }
}
