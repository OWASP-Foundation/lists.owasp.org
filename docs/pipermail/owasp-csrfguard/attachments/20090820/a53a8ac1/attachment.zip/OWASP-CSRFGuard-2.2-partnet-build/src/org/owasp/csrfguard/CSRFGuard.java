/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard;

import java.io.IOException;

import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.handlers.ResponseHandler;
import org.owasp.csrfguard.http.MutableHttpResponse;
import org.owasp.csrfguard.token.TokenStrategy;

/**
 * The CSRFGuard object implements the token validation enforcement and HTML token injection.
 */
public final class CSRFGuard {
	
	/**
	 * Constructor.
	 */
	public CSRFGuard() {
		/**
		 * No class instance variables to initialize
		 */
	}
	
	/**
	 * Verify that the supplied request contains the valid CSRF token for the current session.
	 * @param request
	 * @param response
	 * @param context
	 * @throws IOException
	 * @throws CSRFException
	 */
	public void doRequestEnforce(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws IOException, CSRFException {
		HttpSession session = request.getSession(true);
		
		String oToken = (String)session.getAttribute(GuardContext.TOKEN_VALUE_KEY);
		String oName = (String)session.getAttribute(GuardContext.TOKEN_NAME_KEY);
		String nToken = null;
		if (oName !=null){
			nToken = (String)request.getParameter(oName);
		}
		
		if(oToken == null || oName == null) {
			/**
			 * Set the token in the session and optionally redirect them to a landing page.
			 */
			TokenStrategy tokenStrategy = context.getTokenStrategy();
			try {
				oToken = tokenStrategy.newTokenValue();
				oName = tokenStrategy.newTokenName();
			} catch (Exception e) {
				throw new CSRFException("unable to generate the random token: " + e.getLocalizedMessage(), e);
			}
				
			session.setAttribute(GuardContext.TOKEN_VALUE_KEY, oToken);
			session.setAttribute(GuardContext.TOKEN_NAME_KEY, oName);
			
			String newTokenRedirectPage = context.getNewTokenRedirectPage();
			
			if(newTokenRedirectPage != null) {
				response.sendRedirect(newTokenRedirectPage);
			}
		} else if((oToken == null || nToken == null)) {
			/** FAIL: one or more of the tokens is missing **/
			throw new CSRFException("one or more of the tokens is missing");
		} else if(!oToken.equals(nToken)) {
			/** FAIL: the request token does not match the session token **/
			throw new CSRFException("the request token does not match the session token", oToken, nToken);
		}
	}
	
	/**
	 * Modify the HTML of the response to include the appropriate CSRF token.
	 * @param request
	 * @param response
	 * @param context
	 * @throws CSRFException
	 */
	public void doResponseEnforce(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws CSRFException {
		/** Make sure the token is in the session before invoking the handler **/
		HttpSession session = request.getSession(true);
		String token = (String)session.getAttribute(GuardContext.TOKEN_VALUE_KEY);
		String tokenName = (String)session.getAttribute(GuardContext.TOKEN_NAME_KEY);
		
		/**
		 * No token exists. Generate a new token and store it in the session.
		 */
		if(token == null || tokenName == null) {
			
			try {
				TokenStrategy tokenGenerator = context.getTokenStrategy();
				token = tokenGenerator.newTokenValue();
				tokenName = tokenGenerator.newTokenName();
			} catch (Exception e) {
				throw new CSRFException("unable to generate the random token: " + e.getLocalizedMessage(), e);
			}
			
			session.setAttribute(GuardContext.TOKEN_VALUE_KEY, token);
			session.setAttribute(GuardContext.TOKEN_NAME_KEY, tokenName);
		}
		
		/**
		 * Invoke the appropriate response handler to insert the token in the HTML.
		 */
		ResponseHandler handler = context.getResponseHandler();
		handler.service(request, response, context, token, tokenName);
	}

}
