/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.actions;

import java.util.Map;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public abstract class AbstractAction
{
	private String name = null;
	
	private Map<String, String> parameters = new HashMap<String, String>();
	
	public String getName() {
		return name;
	}
	
	public void setName(final String name) {
		this.name = name;
	}
	
	public void setActionParameter(final String name, final String value) {
		parameters.put(name, value);
	}
	
	public String getActionParameter(final String name) {
		return parameters.get(name);
	}
	
	public int getActionParameterCount() {
		return parameters.size();
	}
	
	/**
	 * Invoked by CSRFGuard when a CSRF attack is detected.
	 * @param request
	 * @param response
	 * @param context
	 * @throws ActionException
	 */
	public abstract void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws ActionException;
}
