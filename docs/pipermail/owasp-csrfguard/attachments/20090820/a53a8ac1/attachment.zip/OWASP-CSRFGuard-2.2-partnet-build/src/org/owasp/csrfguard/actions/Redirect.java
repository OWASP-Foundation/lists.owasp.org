package org.owasp.csrfguard.actions;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;

import org.owasp.csrfguard.GuardContext;
import org.owasp.csrfguard.http.MutableHttpResponse;

public final class Redirect extends AbstractAction {

	@Override
	public void service(HttpServletRequest request, MutableHttpResponse response, GuardContext context) throws ActionException {
		String errorPage = getActionParameter("ErrorPage");
		
		try {
			response.sendRedirect(errorPage);
		} catch (IOException ioe) {
			throw new ActionException(ioe);
		}
	}

}
