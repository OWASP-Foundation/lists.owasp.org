/**
 * OWASP CSRFGuard
 * 
 * This file is part of the Open Web Application Security Project (OWASP)
 * Copyright (c) 2007 - The OWASP Foundation
 * 
 * The CSRFGuard is published by OWASP under the LGPL. You should read and accept the
 * LICENSE before you use, modify, and/or redistribute this software.
 * 
 * @author Eric Sheridan <a href="http://www.aspectsecurity.com">Aspect Security</a>
 * @created 2007
 */

package org.owasp.csrfguard.actions;

public final class ActionException extends Exception {
	
	private final static long serialVersionUID = 0xaae34532;
	
	public ActionException(String msg) {
		super(msg);
	}
	
	public ActionException(Exception e) {
		super(e);
	}
}
